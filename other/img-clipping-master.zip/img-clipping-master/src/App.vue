<template>
	<div id="app">
		<Clip></Clip>
	</div>
</template>

<script>
	import Clip from './components/Clip';

	export default{
		components:{
			Clip,
		}
	}
</script>
