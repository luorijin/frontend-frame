/**
 * 服务器地址
 */
var config = {
    tokenURL: 'http://172.16.10.79:8360/qiniu/gettoken',
    checkURL: 'http://third.172.16.11.49.xip.io/wq.php/record/correct',
    imgDomain: 'http://img.yousi.com/',  //图片域名
    callbackURL: 'http://172.16.10.78:7777/index/content/homework_main.html'
};